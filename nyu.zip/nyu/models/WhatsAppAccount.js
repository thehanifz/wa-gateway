const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const WhatsAppAccount = sequelize.define('WhatsAppAccount', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  sessionId: {
    type: DataTypes.STRING,
    allowNull: false,
    unique: true,
  },
  status: {
    type: DataTypes.ENUM('connected', 'disconnected', 'connecting', 'qr-code', 'error'),
    defaultValue: 'disconnected',
  },
  qrCode: {
    type: DataTypes.TEXT,
    allowNull: true,
  },
  lastConnectedAt: {
    type: DataTypes.DATE,
  },
  userId: {
    type: DataTypes.INTEGER,
    references: {
      model: 'Users',
      key: 'id',
    },
  },
});

module.exports = WhatsAppAccount;
