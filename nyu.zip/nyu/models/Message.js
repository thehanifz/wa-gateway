const { DataTypes } = require('sequelize');
const sequelize = require('../config/database');

const Message = sequelize.define('Message', {
  id: {
    type: DataTypes.INTEGER,
    autoIncrement: true,
    primaryKey: true,
  },
  messageId: {
    type: DataTypes.STRING, // from Baileys
    allowNull: false,
    unique: true,
  },
  direction: {
    type: DataTypes.ENUM('incoming', 'outgoing'),
    allowNull: false,
  },
  from: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  to: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  content: {
    type: DataTypes.TEXT,
  },
  type: {
    type: DataTypes.STRING, // text, image, etc.
  },
  status: {
    type: DataTypes.STRING, // delivered, read, etc.
  },
  timestamp: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  accountId: {
    type: DataTypes.INTEGER,
    references: {
      model: 'WhatsAppAccounts',
      key: 'id',
    },
  },
});

module.exports = Message;
