const sequelize = require('../config/database');
const User = require('./User');
const WhatsAppAccount = require('./WhatsAppAccount');
const Message = require('./Message');
const Log = require('./Log');

// Define associations
User.hasMany(WhatsAppAccount, { foreignKey: 'userId', onDelete: 'CASCADE' });
WhatsAppAccount.belongsTo(User, { foreignKey: 'userId' });

WhatsAppAccount.hasMany(Message, { foreignKey: 'accountId', onDelete: 'CASCADE' });
Message.belongsTo(WhatsAppAccount, { foreignKey: 'accountId' });

const db = {
  sequelize,
  User,
  WhatsAppAccount,
  Message,
  Log,
};

module.exports = db;
