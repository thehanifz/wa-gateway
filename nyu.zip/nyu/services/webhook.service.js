const logger = require("../config/logger");
const { Log } = require("../models");
// Dalam implementasi nyata, URL webhook akan disimpan per user atau per akun di database.
// Untuk contoh ini, kita gunakan variabel statis.
const WEBHOOK_URL = 'https://webhook.site/your-unique-id'; // Ganti dengan URL n8n atau webhook Anda

async function sendWebhook(event, data) {
    if (!WEBHOOK_URL) {
        logger.debug('Webhook URL not set. Skipping webhook.');
        return;
    }

    try {
        const payload = JSON.stringify({ event, data });
        
        await fetch(WEBHOOK_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload,
        });

        logger.info(`Webhook sent for event '${event}'`);
        await Log.create({ level: 'info', message: `Webhook sent for event '${event}'`, meta: payload });

    } catch (error) {
        logger.error(`Failed to send webhook for event '${event}':`, error);
        await Log.create({ level: 'error', message: `Failed to send webhook for event '${event}'`, meta: JSON.stringify(error) });
    }
}

module.exports = { sendWebhook };
