// ==================== REVISI FINAL BAILEYS SERVICE ====================

// Polyfill untuk global.crypto, wajib untuk Baileys di beberapa environment Node.js
const nodeCrypto = require('crypto');
if (typeof global.crypto !== 'object') {
  global.crypto = nodeCrypto.webcrypto;
}

// Polyfill untuk fetch, jaga-jaga jika menggunakan versi Node < 18
if (typeof global.fetch !== 'function') {
  global.fetch = (...args) =>
    import('node-fetch').then(({ default: fetch }) => fetch(...args));
}

const {
  default: makeWASocket,
  useMultiFileAuthState,
  DisconnectReason,
  Browsers
} = require('@whiskeysockets/baileys');
const { Boom } = require('@hapi/boom');
const path = require('path');
const fs = require('fs');
const pino = require('pino');
const qrcode = require('qrcode');
const { WhatsAppAccount, Message } = require('../models');
const logger = require('../config/logger');
const { sendWebhook } = require('./webhook.service');

const sessions = new Map();
const SESSIONS_DIR = path.join(__dirname, '..', 'whatsapp-sessions');

class BaileysService {
  static async init() {
    try {
      const accounts = await WhatsAppAccount.findAll();
      logger.info(`Found ${accounts.length} WhatsApp account(s) to initialize.`);
      for (const account of accounts) {
        // Coba hubungkan kembali jika statusnya bukan 'disconnected'
        if (['connected', 'connecting', 'qr-code'].includes(account.status)) {
          this.connect(account.id);
        }
      }
    } catch (error) {
      logger.error('Error initializing Baileys service:', error);
    }
  }

  static async connect(accountId) {
    if (sessions.has(accountId) && (sessions.get(accountId)?.ws?.isOpen || sessions.get(accountId)?.ws?.isConnecting)) {
      logger.warn(`Session for account ${accountId} is already open or connecting.`);
      return;
    }

    const initialAccount = await WhatsAppAccount.findByPk(accountId);
    if (!initialAccount) {
      logger.error(`Account with ID ${accountId} not found for connection.`);
      return;
    }

    const sessionDir = path.join(SESSIONS_DIR, initialAccount.sessionId);
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

    const sock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      browser: Browsers.ubuntu('Chrome'), // Lebih cocok untuk server Armbian/Debian
      logger: pino({ level: 'silent' }),
    });

    sessions.set(accountId, sock);

    sock.ev.on('creds.update', saveCreds);

    sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect, qr } = update;

      // ====================================================================
      // PERBAIKAN KRUSIAL: Selalu ambil instance akun terbaru dari DB di dalam event handler.
      // Ini memastikan kita tidak bekerja dengan data "basi" (stale data).
      const account = await WhatsAppAccount.findByPk(accountId);
      if (!account) {
        logger.warn(`Account ${accountId} not found during connection update, maybe it was deleted.`);
        sock.logout();
        sessions.delete(accountId);
        return;
      }
      // ====================================================================
      
      try {
        if (qr) {
          const qrCodeDataUrl = await qrcode.toDataURL(qr);
          await account.update({ status: 'qr-code', qrCode: qrCodeDataUrl });
          logger.info(`QR code generated and saved for account ${accountId}.`);
        }

        if (connection === 'close') {
          const statusCode = lastDisconnect?.error instanceof Boom ? lastDisconnect.error.output?.statusCode : 500;

          logger.warn(`Connection closed for account ${accountId}, status code: ${statusCode}`);
          sessions.delete(accountId); // Hapus sesi dari memori

          // Jika di-logout (misal scan dari HP lain), hapus folder sesi dan coba lagi
          if (statusCode === DisconnectReason.loggedOut) {
            logger.warn(`Account ${accountId} logged out. Deleting session files and restarting.`);
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            // Langsung coba konek lagi untuk dapat QR baru
            this.connect(accountId);
          } else {
            // Untuk error lain, set status disconnected dan biarkan user menekan tombol 'connect' lagi
            await account.update({ status: 'disconnected', qrCode: null });
          }
        } else if (connection === 'open') {
          await account.update({ status: 'connected', qrCode: null, lastConnectedAt: new Date() });
          logger.info(`Account ${accountId} connected successfully.`);
        } else if (connection === 'connecting') {
          await account.update({ status: 'connecting' });
          logger.info(`Account ${accountId} is connecting...`);
        }
      } catch(dbError) {
          logger.error(`Failed to update database for account ${accountId}:`, dbError);
      }
    });

    sock.ev.on('messages.upsert', async (m) => {
      const msg = m.messages[0];
       if (!msg?.key?.fromMe && m.type === 'notify') {
        const messageData = {
          messageId: msg.key.id,
          direction: 'incoming',
          from: msg.key.remoteJid,
          to: sock.user?.id.split(':')[0] + '@s.whatsapp.net',
          content: msg.message?.conversation || msg.message?.extendedTextMessage?.text || JSON.stringify(msg.message),
          type: Object.keys(msg.message || {})[0] || 'unknown',
          status: 'received',
          timestamp: new Date(msg.messageTimestamp * 1000),
          accountId: accountId
        };

        const [dbMessage, created] = await Message.findOrCreate({
          where: { messageId: msg.key.id },
          defaults: messageData
        });

        if (created) sendWebhook('message.incoming', dbMessage.toJSON());
      }
    });
  }

  static async disconnect(accountId) {
    const sock = sessions.get(accountId);
    if (sock) {
      await sock.logout();
      sessions.delete(accountId);
      logger.info(`Account ${accountId} disconnected successfully.`);
    } else {
      logger.warn(`No active session found for account ${accountId} to disconnect.`);
    }
    // Pastikan status di DB selalu terupdate
    await WhatsAppAccount.update(
      { status: 'disconnected', qrCode: null },
      { where: { id: accountId } }
    );
    return true;
  }

  static async sendMessage(accountId, to, text) {
    const sock = sessions.get(accountId);
    const account = await WhatsAppAccount.findByPk(accountId);
    if (!sock || account?.status !== 'connected') {
      throw new Error(`Account ${accountId} is not connected.`);
    }

    const result = await sock.sendMessage(to, { text });

    const messageData = {
      messageId: result.key.id,
      direction: 'outgoing',
      from: sock.user.id.split(':')[0] + '@s.whatsapp.net',
      to,
      content: text,
      type: 'text',
      status: 'sent',
      timestamp: new Date(),
      accountId
    };
    const dbMessage = await Message.create(messageData);
    sendWebhook('message.outgoing', dbMessage.toJSON());

    return dbMessage;
  }

  static getSession(accountId) {
    return sessions.get(accountId);
  }
}

module.exports = BaileysService;

