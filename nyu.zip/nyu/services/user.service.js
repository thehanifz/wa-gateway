const { User } = require('../models');
const logger = require('../config/logger');

/**
 * Creates the initial admin user from environment variables if no users exist in the database.
 */
async function createInitialAdmin() {
  try {
    const userCount = await User.count();
    if (userCount === 0) {
      const email = process.env.INITIAL_ADMIN_EMAIL;
      const password = process.env.INITIAL_ADMIN_PASSWORD;

      if (!email || !password) {
        logger.warn('Initial admin credentials not found in .env. Skipping creation.');
        return;
      }
      
      await User.create({
        email,
        password,
        role: 'admin',
      });
      logger.info(`Initial admin user created: ${email}`);
    }
  } catch (error) {
    logger.error('Failed to create initial admin user:', error);
  }
}

module.exports = { createInitialAdmin };
