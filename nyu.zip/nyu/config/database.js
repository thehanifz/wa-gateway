const { Sequelize } = require('sequelize');
const logger = require('./logger');
require('dotenv').config();

const sequelize = new Sequelize({
  dialect: 'sqlite',
  storage: process.env.DB_STORAGE || './whatsapp_gateway.sqlite',
  logging: (msg) => logger.debug(msg), // Use pino logger for SQL logs
});

module.exports = sequelize;
