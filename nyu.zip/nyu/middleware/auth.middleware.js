const ensureAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  res.redirect('/login');
};

const hasRole = (roles) => {
  return (req, res, next) => {
    if (!req.isAuthenticated()) {
      return res.status(401).send('Unauthorized');
    }
    if (roles.includes(req.user.role)) {
      return next();
    }
    res.status(403).send('Forbidden: You do not have the required role.');
  };
};

module.exports = {
  ensureAuthenticated,
  hasRole,
};
