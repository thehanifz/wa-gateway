const express = require('express');
const router = express.Router();
const logger = require('../config/logger');

// Endpoint untuk menerima data dari n8n atau platform lain
router.post('/trigger', (req, res) => {
    logger.info('Webhook received from external service:', req.body);
    
    // Logika untuk memproses webhook, misalnya mengirim pesan WhatsApp
    // const { action, payload } = req.body;
    // if (action === 'sendMessage') {
    //     BaileysService.sendMessage(payload.accountId, payload.to, payload.text);
    // }

    res.status(200).json({ message: 'Webhook received' });
});

module.exports = router;
