const express = require('express');
const { ensureAuthenticated } = require('../middleware/auth.middleware');
const { WhatsAppAccount, Message } = require('../models');
const BaileysService = require('../services/baileys.service');
const router = express.Router();

// Main Dashboard
router.get('/', ensureAuthenticated, async (req, res) => {
  try {
    const accounts = await WhatsAppAccount.findAll({ 
        where: { userId: req.user.id },
        order: [['createdAt', 'DESC']]
    });
    const recentMessages = await Message.findAll({
        // Ini perlu join untuk mendapatkan pesan hanya dari akun milik user
        include: [{
            model: WhatsAppAccount,
            where: { userId: req.user.id },
            attributes: ['name']
        }],
        limit: 20,
        order: [['timestamp', 'DESC']]
    });

    res.render('dashboard', { user: req.user, accounts, recentMessages });
  } catch (error) {
    console.error(error);
    res.status(500).send("Error loading dashboard");
  }
});

// Add new WhatsApp Account
router.post('/accounts/add', ensureAuthenticated, async (req, res) => {
    const { name } = req.body;
    try {
        const newAccount = await WhatsAppAccount.create({
            name,
            sessionId: `session-${req.user.id}-${Date.now()}`,
            userId: req.user.id,
        });
        // Start the connection process
        BaileysService.connect(newAccount.id);
        res.redirect('/');
    } catch(error) {
        console.error(error);
        res.status(500).send("Failed to add account");
    }
});

// Connect Account
router.post('/accounts/connect/:id', ensureAuthenticated, async (req, res) => {
    await BaileysService.connect(parseInt(req.params.id));
    res.redirect('/');
});

// Disconnect Account
router.post('/accounts/disconnect/:id', ensureAuthenticated, async (req, res) => {
    await BaileysService.disconnect(parseInt(req.params.id));
    res.redirect('/');
});


module.exports = router;
