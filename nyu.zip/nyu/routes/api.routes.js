const express = require('express');
const { ensureAuthenticated, hasRole } = require('../middleware/auth.middleware');
const BaileysService = require('../services/baileys.service');
const { WhatsAppAccount } = require('../models');
const router = express.Router();

// Middleware to check API key in a real scenario
// const checkApiKey = (req, res, next) => { next(); };

// Send Message Endpoint
router.post('/send', ensureAuthenticated, hasRole(['admin', 'operator']), async (req, res) => {
    const { accountId, to, text } = req.body;

    if (!accountId || !to || !text) {
        return res.status(400).json({ error: 'Missing required fields: accountId, to, text' });
    }

    try {
        // Ensure the user owns this account
        const account = await WhatsAppAccount.findOne({ where: { id: accountId, userId: req.user.id }});
        if (!account) {
            return res.status(403).json({ error: 'You do not have permission to use this account.' });
        }
        
        const result = await BaileysService.sendMessage(accountId, to, text);
        res.status(200).json({ success: true, message: 'Message sent successfully', data: result });
    } catch (error) {
        console.error("API Send Error:", error);
        res.status(500).json({ success: false, error: error.message });
    }
});

// Get Account Status
router.get('/status/:id', ensureAuthenticated, async (req, res) => {
    try {
        const account = await WhatsAppAccount.findOne({ where: { id: req.params.id, userId: req.user.id }});
        if (!account) {
            return res.status(404).json({ error: 'Account not found or not owned by you.' });
        }
        res.status(200).json({ status: account.status, qrCode: account.qrCode });
    } catch(error) {
        res.status(500).json({ error: 'Internal server error' });
    }
});

module.exports = router;
