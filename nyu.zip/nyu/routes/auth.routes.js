const express = require('express');
const passport = require('passport');
const router = express.Router();

// Login page
router.get('/login', (req, res) => {
    res.render('login');
});

// Handle Local Login
router.post('/login', passport.authenticate('local', {
  successRedirect: '/',
  failureRedirect: '/auth/login',
  // failureFlash: true // aktifkan jika menggunakan connect-flash
}));

// Handle Google Login
router.get('/google', passport.authenticate('google', { scope: ['profile', 'email'] }));

// Google Callback
router.get('/google/callback', passport.authenticate('google', {
  successRedirect: '/',
  failureRedirect: '/auth/login'
}));


// Handle Logout
router.post('/logout', (req, res, next) => {
  req.logout((err) => {
    if (err) { return next(err); }
    res.redirect('/auth/login');
  });
});

module.exports = router;
